from .cpi import CPI
from .inflation import Inflation
from .predict import predict
